  const burger = document.getElementById('burger');
  const nav = document.getElementById('desktopMenu');

  burger.addEventListener('click', () => {
    nav.classList.toggle('active');
  });

 window.addEventListener('scroll', function () {
  const scrolled = window.scrollY;
  document.querySelector('.background').style.transform = `translateY(${scrolled * 0.5}px)`;
});